package Harpia;
import robocode.*;
import java.awt.Color;


 //ROBOFINAL - a robot by zial, palomitas de leticia, mi kasa su kasa
 
public class Harpia extends AdvancedRobot
{
	/**
	 * run: ROBOFINAL's default behavior
	 */
	public void run() {

		setColors(Color.darkGray,Color.black,Color.lightGray,Color.red,Color.blue); // body,gun,radar

		// Robot main loop
		//vai pra frente, gira pistoleta
		while(true) {
			// Replace the next 4 lines with any behavior you would like
			setAhead(100);
			setTurnRight(100);
			turnGunRight(360);
			setTurnRight(100);
			turnGunRight(360);
			setTurnRight(100);
			turnGunRight(360);
			
		}
	}

	/**
	 * onScannedRobot: What to do when you see another robot
	 */
	

	public void onScannedRobot(ScannedRobotEvent e) {
		// Replace the next line with any behavior you would like
		
		if((getEnergy()<70)&&(e.getEnergy()>getEnergy()))
		{
			setAhead(e.getDistance()-100);
			setTurnRight(e.getBearing());
			
			double pontariatop=getHeading()+e.getBearing();
			double pontaria=anguloRelNorm(pontariatop-getGunHeading());
			
			if (Math.abs(pontaria)<=3);
			{
				turnGunRight(pontaria);
				if (getGunHeat() == 0)
					fire(1.5);
			}
				turnGunRight(pontaria);
			if (pontaria == 0)
				scan();
			}
			//
			else
			{
				setTurnRight(e.getBearing());
				setAhead(e.getDistance());
				double pontariatop=getHeading()+e.getBearing();
				double pontaria=anguloRelNorm(pontariatop-getGunHeading());
			//
				if (Math.abs(pontaria)<=3)
				{
					turnGunRight(pontaria);
					if (getGunHeat() == 0)
					fire(2.5);
				}
				else
					turnGunRight(pontaria);
				if (pontaria == 0)
					scan();
			}
	}
	
			public void onWin(WinEvent e)
			{
				turnRight(36000);
			}
			
			public double anguloRelNorm(double angulo)
			{
		
				return -1.0;
			}
			
			public void onHitRobot(HitRobotEvent e){
			fire(3);
			}
			


}
